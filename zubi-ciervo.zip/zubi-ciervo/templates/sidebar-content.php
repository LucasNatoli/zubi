<?php
/**
  * Template Name: Sidebar-Content
 *
 * Displays a full width page with a sidebar of the left.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package ZUBI
 */


get_header(); ?>


<div class="container fondo-blanco">
  <div class="row breadcrumb">BREADCRUMB</div>
  <div class="row">
    <div class="col-4 home-tarjeta">
      <?php get_sidebar()?>
    </div>
    <div class="col-8 home-tarjeta">
      <?php
		while ( have_posts() ) : the_post();

			get_template_part( 'template-parts/content', 'page' );

		endwhile; // End of the loop.
?>
    </div>
  </div>
</div>

<?php get_footer(); ?>
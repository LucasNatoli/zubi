<?php
/**
 * Template Name: Front Page
 * The main template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package ZUBI
 */

get_header(); ?>


	<main>
		<section class="jumbotron text-center">
			<div class="container">
				<h1 class="blanco">Zubi es la comunidad de la clase empresarial</h1>
				<h3 class="blanco">Aprende con los mejores profesionales y forma parte de la mayor comunidad para empresarios</h3>
				<p>
					<a href="#" class="btn btn-primary">VER SERVICIOS</a>
					<a href="#" class="btn btn-primary">CREAR CUENTA</a>
				</p>
			</div>
		</section>

		<div class="container-fluid padding-grande fondo-blanco">
			<div class="row fila-centrada">
				<div class="col-sm home-tarjeta">
					<i class="material-icons rounded-circle circulo-70 home-iconos">play_arrow</i>
					<h2>Capacitaciones</h2>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
					<a href="#" class="btn btn-primary">VER SERVICIO</a>
				</div>
				<div class="col-sm home-tarjeta">
					<i class="material-icons rounded-circle circulo-70 home-iconos">event_available</i>
					<h2>Consultorias</h2>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
					<a href="#" class="btn btn-primary">VER SERVICIO</a>
				</div>
				<div class="col-sm home-tarjeta">
					<i class="material-icons rounded-circle circulo-70 home-iconos">card_giftcard</i>
					<h2>Packs</h2>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
					<a href="#" class="btn btn-primary">VER SERVICIO</a>
				</div>
			</div>
		</div>

		<div class="container-fluid fondo-azul">
			<div class="row zubi-cta">
				<div class="col-2"></div>
				<div class="col-4 text-left" style="display: flex; flex-direction: column; justify-content: center; align-items: flex-start;">
					<h2 class="blanco">ÚNETE A LA COMUNIDAD</h1>
					<p class="blanco">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
					<div class="container" style="padding:0px">
						<a href="#" class="btn btn-primary">VER SERVICIO</a>
						<a href="#" class="btn btn-primary">CREAR CUENTA</a>
					</div>
				</div>
				<div class="col-4 text-center" style="display: flex; flex-direction: column; justify-content: center; align-items: flex-start;">
					<img src="<?php echo get_template_directory_uri() . '/images/video-conf.png'; ?>">
				</div>
				<div class="col-2"></div>
			</div>
		</div>

		<div class="container-fluid fondo-blanco">
			<h1 class="centrado" style="padding-top: 40px">Creamos valor para tu PyME</h1>
			<div class="row fila-centrada">
				<div class="col-sm home-tarjeta">
					<i class="material-icons rounded-circle circulo-70 home-iconos">check</i>
					<h2>Ágil</h2>
					<p>Pensamos una plataforma para que puedas acceder de una forma sencilla, amigable y dinámica a todo lo que tu PyME necesita.</p>
				</div>
				<div class="col-sm home-tarjeta">
					<i class="material-icons rounded-circle circulo-70 home-iconos">cloud_queue</i>
					<h2>Online</h2>
					<p>Desde cualquier lugar del país vas a poder acceder a todos nuestros servicios sin inconvenientes.</p>
				</div>
				<div class="col-sm home-tarjeta">
					<i class="material-icons rounded-circle circulo-70 home-iconos">star_border</i>
					<h2>Accesible</h2>
					<p>Te conectamos con los mejores profesionales de cada área, a un precio lógico, optimizando costos innecesarios.</p>
				</div>

			</div>
			<div class="row fila-centrada">
				<div class="col-sm home-tarjeta">
					<i class="material-icons rounded-circle circulo-70 home-iconos">sync</i>
					<h2>Integral</h2>
					<p>Te ofrecemos asesoramiento en áreas fundamentales sin importar en qué etapa de desarrollo se encuentre tu PyME. 
</p>
				</div>
				<div class="col-sm home-tarjeta">
					<i class="material-icons rounded-circle circulo-70 home-iconos">search</i>
					<h2>Dedicados</h2>
					<p>Contamos con un equipo de profesionales con experiencia para atender cada proyecto con la misma atención. 
</p>
				</div>
				<div class="col-sm home-tarjeta">
					<i class="material-icons rounded-circle circulo-70 home-iconos">security</i>
					<h2>Seguro</h2>
					<p>trabajamos bajo protocolos de seguridad que brindan tranquilidad y confianza a nuestros profesionales y clientes.</p>
				</div>

			</div>
		</div>
	</main>



<?php get_footer(); ?>

<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package ZUBI
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>

<head>
  <meta charset="<?php bloginfo( 'charset' ); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="profile" href="https://gmpg.org/xfn/11">

  <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

  <div id="page" class="site">
    <a class="skip-link screen-reader-text" href="#content">
      <?php esc_html_e( 'Skip to content', 'zubi-ciervo' ); ?></a>

    <header>
      <nav class="navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>">
          <img width="103" height="88" 
            src="<?php echo get_template_directory_uri() . '/images/logo' . (is_front_page() ? '-front-page': '') . '.png'; ?>" 
            class="custom-logo" alt="ZUBI" itemprop="logo" />
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown"
          aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
              <a class="nav-link" href="#">Nosotros</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                Servicios
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                <a class="dropdown-item" href="#">Capacitaciones</a>
                <a class="dropdown-item" href="#">Consultorías</a>
              </div>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Packs</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Contacto</a>
            </li>
          </ul>
          <form class="form-inline">
            <input class="form-control mr-sm-2" type="search" placeholder="Ingresa tu busqueda" aria-label="Search">
            <button class="btn btn-secondary my-2 my-sm-0" type="submit">Buscar</button>
          </form>


          <ul class="navbar-nav flex-row ml-md-auto d-none d-md-flex">
            <li class="nav-item">
              <a class="nav-link p-2" href="https://www.facebook.com/" target="_blank" aria-label="Facebook">
                <img src="<?php echo get_template_directory_uri() . '/images/zubi-face.png'; ?>" />
                <div class="ripple-container"></div>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link p-2" href="https://www.instagram.com/" target="_blank" aria-label="Instagram">
                <img src="<?php echo get_template_directory_uri() . '/images/zubi-insta.png'; ?>" />
                <div class="ripple-container"></div>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link p-2" href="https://www.linkedin.com/" target="_blank" aria-label="Linkedin">
                <img src="<?php echo get_template_directory_uri() . '/images/zubi-linkedin.png'; ?>" />
                <div class="ripple-container"></div>
              </a>
            </li>
          </ul>
        </div>
      </nav><!-- #site-navigation -->
    </header><!-- #masthead -->

    <div id="content" class="site-content">
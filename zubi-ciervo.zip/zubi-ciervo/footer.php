<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package ZUBI
 */

?>

</div><!-- #content -->



<footer class="container-fluid" style="background-color:#353854; color: white">
  <div class="container text-center flex-row site-footer">
    <div class="row">
      <div class="col-sm" style="padding: 80px 15px">
        <i class="material-icons" style="font-size: 64px;">location_on</i>
        <p>Buenos Aires - Calle 1800, Localidad. Argentina.</p>
      </div>
      <div class="col-sm" style="padding: 80px 15px">
        <i class="material-icons" style="font-size: 64px;">email</i>
        <p>contacto@zubi.com.ar</p>
      </div>
      <div class="col-sm" style="padding: 80px 15px">
        <i class="material-icons" style="font-size: 64px;">phone</i>
        <p>+1 (555) 345 234343</p>
      </div>
      <div class="col-sm flex-row" style="background-color:#fc6a42; padding: 80px 15px">

        <ul class="navbar-nav flex-row ml-md-auto d-none d-md-flex">
          <li class="nav-item">
            <a class="nav-link p-2" href="https://www.facebook.com/" target="_blank" aria-label="Facebook">
              <img src="<?php echo get_template_directory_uri() . '/images/zubi-face.png'; ?>" />
              <div class="ripple-container"></div>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link p-2" href="https://www.instagram.com/" target="_blank" aria-label="Instagram">
              <img src="<?php echo get_template_directory_uri() . '/images/zubi-insta.png'; ?>" />
              <div class="ripple-container"></div>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link p-2" href="https://www.linkedin.com/" target="_blank" aria-label="Linkedin">
              <img src="<?php echo get_template_directory_uri() . '/images/zubi-linkedin.png'; ?>" />
              <div class="ripple-container"></div>
            </a>
          </li>
        </ul>

      </div>
    </div>
  </div>

</footer><!-- #footer -->


</div><!-- #page -->

<?php wp_footer(); ?>

</body>

</html>